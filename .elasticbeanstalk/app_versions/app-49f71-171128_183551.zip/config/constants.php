<?php
/**
 * Created by PhpStorm.
 * User: emil
 * Date: 2017/7/10
 * Time: 20:26
 */
return [
    'CDN_HOST' => '//cdn.multiverseinc.com/'
];